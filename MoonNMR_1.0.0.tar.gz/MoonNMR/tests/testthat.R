library(testthat)
library(MoonNMR)

test_check("MoonNMR")
